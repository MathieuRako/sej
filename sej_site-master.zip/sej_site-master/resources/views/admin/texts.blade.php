@extends('admin.template',['breadcrumbs' => ['texts']])

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
               <a href = "texts/informations">Informations</a>
               <a href = "texts/home">Home</a>
               <a href = "texts/club">Club </a>
               <a href = "texts/belts">Belts </a>
               <a href = "texts/contact">Contact</a>
               <a href = "texts/sponsors">Sponsors</a>
               <a href = "texts/judo">Judo</a>


            </div>
        </div>
    </div>
</div>
@endsection